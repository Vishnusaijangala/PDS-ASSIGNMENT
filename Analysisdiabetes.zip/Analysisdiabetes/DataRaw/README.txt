1. The "diabetes.csv" file contains the data of 768 patients. These data have 8 attributes (For example, Blood Pressure, Blood Pressure, Skin Thickness, Insulin, BMI, Sugar Pedigree Function and Age) and 1 response variable (Value). Different answers The result has a binary value (1 result means diabetes, 0 means no diabetes) and we consider all data as a population

a) for our analysis.
First, we create a sample of size 25 from the population and find the average and maximum amount of sugar for this sample and compare the statistics with the population statistics for the same difference. Create bar charts and pie charts to visualize comparisons.


b) Then find the 98th percentile of the sample and population BMI and compare the results using a graph (bar and pie chart)

c) Using Bootstrap (switch = True), create 500 samples from the population (150 observations per sample) and find the mean, standard deviation and percentage of blood pressure and compare them with all statistics of the variables and generate graphs (bar and chart) to compare.
All results are saved in the received file.